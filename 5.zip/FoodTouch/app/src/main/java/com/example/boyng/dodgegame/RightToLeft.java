package com.example.boyng.dodgegame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.Log;

import java.util.Random;

class RightToLeft {
    private float ycount = 0;
    private float yycount = 100;
    private float[] yCount = new float[8];
    private float[] yyCount = new float[8];
    private float[] x = new float[8];
    private float[] y = new float[8];
    private float[] xx = new float[8];
    private float[] yy = new float[8];
    public Rect[] rect = new Rect[7];
    private float[] xr = new float[8];
    private float xxr;
    private Rect bRect;
    private Bitmap potato;
    Random rand = new Random();

    public RightToLeft(Bitmap potato) {  // 다른것은 y좌표가 변하는것이아닌 x좌표가 --됨

        for (int i = 0; i < 7; i++) {
            yCount[i] += ycount;
            ycount += 267;
            y[i] += yCount[i];
            yyCount[i] += yycount;
            yycount += 267;
            yy[i] += yyCount[i];
            x[i] = 970;
            xx[i] = 1070;
        }
        this.potato = potato;
        bRect = new Rect(0,0, potato.getWidth(), potato.getHeight());
        randPo();

    }

    public void increase() {
        resetPos();
        for (int i = 0; i < 7; i++) {
            y[i] += xr[i];
            yy[i] += xr[i];
            x[i]--;
            xx[i]--;
            rect[i] = new Rect((int)x[i], (int)y[i], (int)xx[i], (int)yy[i]);
        }
    }

    public void resetPos() {
        for (int i = 0; i < 7; i++) {
            if (x[i] < -100 || y[i] < -100 || y[i] > 1870) {
                x[i] = rand.nextInt(200)+1170;
                xx[i] = x[i] + 100;
                y[i] = yCount[i];
                yy[i] = yyCount[i];
                xxr = rand.nextFloat();
                xr[i] = rand.nextFloat() - xxr;
            }
        }
    }

    public void randomSet(int index) {
        x[index] = rand.nextInt(200)+1170;
        xx[index] = x[index] + 100;
        y[index] = yCount[index];
        yy[index] = yyCount[index];
        xxr = rand.nextFloat();
        xr[index] = rand.nextFloat() - xxr;
    }

    public void randPo() {
        for (int i = 0; i < 5; i++) {
            xxr = rand.nextFloat();
            xr[i] = rand.nextFloat() - xxr;
        }
    }

    public void onDraw(Canvas canvas) {
        for(int i = 0; i < 7; i++)
            canvas.drawBitmap(potato, bRect, rect[i], null);
    }

}
