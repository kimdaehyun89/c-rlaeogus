package com.example.boyng.dodgegame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;

import java.util.Timer;
import java.util.TimerTask;

public class MyView extends View {
    Paint paint;
    Timer timer;
    private Bitmap hamburger,hotdog, pizza, potato, up, down,boomSprite;
    TopToFall topToFall;
    BottomToUp bottomToUp;
    LeftToRight leftToRight;
    RightToLeft rightToLeft;
    ClickEvent clickEvent;
    UiEvent uiEvent;
    Rect click = new Rect();
    private int x, y;
    private int touchCount = 0;
    public int speed;
    private String str = "터치하면 시작!!";
    private String str1 = "";

    public MyView(Context context) {
        super(context);
        BitmapDrawable drawable = (BitmapDrawable)getResources().getDrawable(R.drawable.hamburger, null);  //햄버거 이미지불러오기
        hamburger = drawable.getBitmap();
        BitmapDrawable drawable1 = (BitmapDrawable)getResources().getDrawable(R.drawable.hotdog, null);   // 핫도그 이미지불러오기
        hotdog = drawable1.getBitmap();
        BitmapDrawable drawable2 = (BitmapDrawable)getResources().getDrawable(R.drawable.pizza, null);  // 피자 이미지불러오기
        pizza = drawable2.getBitmap();
        BitmapDrawable drawable3 = (BitmapDrawable)getResources().getDrawable(R.drawable.potato, null);  // 포테이토 이미지불러오기
        potato = drawable3.getBitmap();
        BitmapDrawable drawable4 = (BitmapDrawable)getResources().getDrawable(R.drawable.up, null);   //속도업에 사용할 비트맵 이미지불러오기
        up = drawable4.getBitmap();
        BitmapDrawable drawable5 = (BitmapDrawable)getResources().getDrawable(R.drawable.down, null);  //속도다운에 사용할 비트맵 이미지 불러오기
        down = drawable5.getBitmap();
        BitmapDrawable drawable6 = (BitmapDrawable)getResources().getDrawable(R.drawable.boomani, null);  //음식 터치시 보여줄 애니메이션 스프라이트 이미지 불러오기
        boomSprite = drawable6 .getBitmap();

        clickEvent = new ClickEvent(hamburger, hotdog, pizza, potato, boomSprite, context);  //clickEvent클래스 생성, 생성자안에다 context포함 비트맵넘겨줌
        topToFall = new TopToFall(hamburger);     //topToFall클래스 생성, 위에서떨어지는 이미지는 햄버거이므로 햄버거 비트맵만 넘겨줌
        bottomToUp = new BottomToUp(hotdog);      //bottomToUp클래스 생성, 아래서위로 올라가는 이미지는 핫도그이므로 핫도그 비트맵만 넘겨줌
        leftToRight = new LeftToRight(pizza);  //leftToRight클래스 생성, 왼쪽에서 오른쪽으로 가는 이미지는 피자, 햄버거이미지이므로 두개의비트맵만 넘겨줌
        rightToLeft = new RightToLeft(potato);   //rightToLeft클래스 생성, 오른쪽에서 왼쪽으로가는 이미지는 포테이토, 핫도그 이미지이므로 두개의비트맵만 넘겨줌
        uiEvent = new UiEvent(up, down);   //uiEvent클래스 생성, ui에 필요한 화살표키 두개의 비트맵을 넘겨줌
        paint = new Paint();   //onDraw함수에 사용할 paint 생성
        topToFall.increase();  //해당클래스의 함수 호출
        bottomToUp.increase();  //해당클래스의 함수 호출
        leftToRight.increase(); //해당클래스의 함수 호출
        rightToLeft.increase(); //해당클래스의 함수 호출
        speed = 5;  //처음 타이머의 period는 5
        timer = new Timer();  //타이머 생성
    }

    private void startTimer(){   //타이머 함수
        timer.cancel();  // cancel을 써줘야 period의 값이 변하게되면 변하게된 값을 가지고 new Timer가 가능
        timer = new Timer(); //타이머 생성
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                topToFall.increase();  //그림이 움직이는 좌표값이 있는 함수
                bottomToUp.increase(); //그림이 움직이는 좌표값이 있는 함수
                leftToRight.increase(); //그림이 움직이는 좌표값이 있는 함수
                rightToLeft.increase(); //그림이 움직이는 좌표값이 있는 함수
                invalidate();   //화면갱신
            }
        }, 0, uiEvent.speed);  //uiEvent클래스에 있는 speed를 가져옴
    }

    public void onDraw(Canvas canvas){
        topToFall.onDraw(canvas);  //canvas를 해당클래스의 onDraw함수안에 넣어서 넘겨줌
        bottomToUp.onDraw(canvas);  //canvas를 해당클래스의 onDraw함수안에 넣어서 넘겨줌
        leftToRight.onDraw(canvas);  //canvas를 해당클래스의 onDraw함수안에 넣어서 넘겨줌
        rightToLeft.onDraw(canvas);  //canvas를 해당클래스의 onDraw함수안에 넣어서 넘겨줌
        clickEvent.onDraw(canvas);  //canvas를 해당클래스의 onDraw함수안에 넣어서 넘겨줌
        uiEvent.onDraw(canvas);    //canvas를 해당클래스의 onDraw함수안에 넣어서 넘겨줌
        paint.setTextSize(100);    //텍스트사이즈100
        paint.setStrokeWidth(10);  //width10
        paint.setStyle(Paint.Style.STROKE); //채우기 없이 테두리만 그림
        if(clickEvent.second == 0) {  //남은 시간(초)가 0이되면
            str = "당신의 점수는 : " + clickEvent.score; //score를 보여줌
            str1 = "다시시작하려면 터치!!";
            timer.cancel(); //타이머 멈춤
        }
        canvas.drawText(str, 230, 900, paint);  //str그림
        canvas.drawText(str1, 150, 1000, paint); // st1그림
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {  //터치 이벤트 함수
        x = (int)event.getX();  //터치한 x좌표를 변수x에 저장
        y = (int)event.getY();  //터치한 y좌표를 변수y에 저장
        touckCheck(x, y);  //변수x, y를 해당 함수의 매게변수로 넘겨줌
        return performClick(); //
    }

    void touckCheck(int x, int y){
        click = new Rect(x-10, y-10, x+10, y+10);  //클릭한 좌표로 rect를 만들어줌
        clickEvent.click(click, topToFall.rect, bottomToUp.rect, leftToRight.rect, rightToLeft.rect, uiEvent.mode, uiEvent.speedText); //클릭한좌표(rect)를 해당클래스의 함수에 넘겨줌, 그림들의 위치 rect형 배열을 넘겨줌
        uiEvent.click(click, clickEvent.score);  //해당클래스의 함수에 클릭한좌표(rect), 현재점수를 넘겨줌
        topToFall.randomSet(clickEvent.index);  // 터치한 그림의 index값을 해당클래스의 함수에 넘겨줌
        bottomToUp.randomSet(clickEvent.index1);  // 터치한 그림의 index값을 해당클래스의 함수에 넘겨줌
        leftToRight.randomSet(clickEvent.index2);  // 터치한 그림의 index값을 해당클래스의 함수에 넘겨줌
        rightToLeft.randomSet(clickEvent.index3);  // 터치한 그림의 index값을 해당클래스의 함수에 넘겨줌
        clickEvent.index = 5;  //index는 원래 4까지인데 존재하지 않는 범위 5까지 설정해줌 그래야 0~4까지의 위치에있는 그림만 터치시 화면밖으로 나가게됨
        clickEvent.index1 = 5; //위와같음
        clickEvent.index2 = 7; //위와같음
        clickEvent.index3 = 7;  //위와같음
        if(uiEvent.mode)   //정지버튼을누르면 즉 mode가 true면 타이머 멈춤
            timer.cancel();
        if(!uiEvent.mode)  //mode가 false인 상태 즉 정지상태가 아닐때는 터치할때마다 new Timer해줌 그래야 타이머의 period의 값이 변하면 적용가능
            startTimer();
            str = "";
        if(clickEvent.second == 0) //남은시간이 0이되면
            touchCount++;
        if(touchCount == 2) {  //화면을 두번터치하면
            touchCount = 0;
            clickEvent.second = 180;  //남은시간을 180으로 다시설정
            str = "";
            str1 = "";
            clickEvent.mode = false;   //mode를 flase로 해줘야 clickEvent에 있는 타이머가 실행됨 그래야 남은시간이 줄어듬
            clickEvent.score = 0;  //점수 score 0으로 다시설정
            startTimer(); //화면 두번터치시 Timer 시작
        }
    }

}
