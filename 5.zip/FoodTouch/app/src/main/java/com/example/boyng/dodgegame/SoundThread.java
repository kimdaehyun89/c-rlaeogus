package com.example.boyng.dodgegame;

import android.content.Context;
import android.media.MediaPlayer;
import android.util.Log;
import android.view.SurfaceHolder;

public class SoundThread extends Thread implements SurfaceHolder.Callback {
    public MediaPlayer successSound, failSound;
    private Context context;
    private int num, soundNumber;

    public SoundThread(Context context, int num) {
        this.context = context;
        this.num = num;
        this.soundNumber = soundNumber;
    }

    @Override
    public void run() {
        if(num == 0) {        // num이 0이면, 즉 터치해야하는 그림을 제대로 터치했을때
            successSound = MediaPlayer.create(context, R.raw.success);
            successSound.start();
            successSound.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    successSound.release();    // 효과음이 끝나면 메모리에서 release
                }});
        }
        if(num == 1)   // num이 1이면, 즉 터치해야하는 그림을 제대로 터치하지 못했을때
        {
            failSound = MediaPlayer.create(context, R.raw.fail);
            failSound.start();
            failSound.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    failSound.release();                     // 효과음이 끝나면 메모리에서 release
                }
            });
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }
}
