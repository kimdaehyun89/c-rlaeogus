package com.example.boyng.dodgegame;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.icu.util.LocaleData;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class ClickEvent {
    public int index;
    public int index1;
    public int index2;
    public int index3;
    private Paint paint;
    private Paint paint1;
    private Bitmap[] bitmap = new Bitmap[4];
    private Rect[] rects = new Rect[9];
    private Bitmap boomSprite;
    private int time = 0;
    private int count = 0;
    private int count1 = 0;
    private int count4 = 0;
    private int soundCount = 0;
    public int score = 0;
    private int touchTime = 0;
    private ArrayList<Rect> list = new ArrayList<Rect>();
    private ArrayList<MyThread> list1 = new ArrayList<MyThread>();
    private ArrayList<SoundThread> list2 = new ArrayList<>();
    public MyThread myThreads;
    public SoundThread soundThread;
    private Timer timer;
    private Random rand = new Random();
    private int delta = 0;
    public int second = 180;
    public boolean mode;
    private String str = "남은시간 : ";
    private Context context;

    public ClickEvent(Bitmap hamburger, Bitmap hotdog, Bitmap pizza, Bitmap potato, Bitmap boomSprite, Context context) {
        paint = new Paint();
        paint1 = new Paint();
        bitmap[0] = hamburger;
        bitmap[1] = hotdog;
        bitmap[2] = pizza;
        bitmap[3] = potato;
        this.boomSprite = boomSprite;
        boomCut();    // 그림터치시 보여줄 그림을 자를 함수
        startTimer(); // 남은시간을 보여줄 타이머
        this.context = context;  // context를 가져와야 MediaPlayer를 사용할수있음
    }

    private void boomCut() {
        int width = boomSprite.getWidth() / 9;      // 그림의 가로를 9로 나눠 width변수에 저장
        int height = boomSprite.getHeight();      // 그림의 세로를 height변수에 저장
        for(int i = 0; i < 9; i++)
            rects[i] = new Rect(i*width, 0, (i+1) * width, height);  // boomSprite그림을 균등하게 9조각으로 잘라 rects에 저장
    }

    public void click(Rect click, Rect[] rect, Rect[] rect1, Rect[] rect2, Rect[] rect3, boolean mode, int speedText) { //화면 터치시 발생하는 함수
        if (!mode) {  //mode가 false일때만, 즉 게임이 정지 상태가 아닐때
            for (int i = 0; i < rect.length; i++)
                if (click.intersect(rect[i])) {   //햄버거 그림을 터치 했을때
                    index = i; // 터치한 그림이 있는 배열위치의 인덱스값을 변수 index에 저장함
                    list.add(rect[i]);  //터치한 그림의 위치(rect)를 list에 add함
                    myThreads = new MyThread(); // Thread를 상속받은 MyThread클래스 생성
                    list1.add(myThreads);       // list1에 myThread클래스를 add함
                    list1.get(count4).start();  // list1의 count4를 start함
                    touchTime = 0;
                    count4++;   // count4를 ++시킴으로써 이미 종료된 쓰레드는 list1에서 get할수가 없음
                    if (count1 != 0 && score > 0)   // 햄버거그림이아니고 점수가 0보다 크면은 점수를 뺴줌
                        score--;
                    if(count1 != 0)        // 햄버거 그림이 아닌 다른 그림을 터치시
                        failMedia();       // 실패 효과음
                    if (count1 == 0) {   // 햄버거 그림이 맞을시
                        score += speedText;  // 점수를 올림
                        successMedia();   // 성공 효과음
                    }
                }
            for (int i = 0; i < rect1.length; i++)
                if (click.intersect(rect1[i])) {          // 위와 같음
                    index1 = i;
                    list.add(rect1[i]);
                    myThreads = new MyThread();
                    list1.add(myThreads);
                    list1.get(count4).start();
                    count4++;
                    touchTime = 0;
                    if (count1 != 1 && score > 0)
                        score--;
                    if(count1 != 1)
                        failMedia();
                    if (count1 == 1) {
                        score += speedText;
                        successMedia();
                    }
                }
            for (int i = 0; i < rect2.length; i++)
                if (click.intersect(rect2[i])) {       // 위와 같음
                    index2 = i;
                    list.add(rect2[i]);
                    myThreads = new MyThread();
                    list1.add(myThreads);
                    list1.get(count4).start();
                    count4++;
                    touchTime = 0;
                    if (count1 != 2 && score > 0)
                        score--;
                    if(count1 != 2)
                        failMedia();
                    if (count1 == 2) {
                        score += speedText;
                        successMedia();
                    }
                }
            for (int i = 0; i < rect3.length; i++)
                if (click.intersect(rect3[i])) {       // 위와 같음
                    index3 = i;
                    list.add(rect3[i]);
                    myThreads = new MyThread();
                    list1.add(myThreads);
                    list1.get(count4).start();
                    count4++;
                    touchTime = 0;
                    if (count1 != 3 && score > 0)
                        score--;
                    if(count1 != 3)
                        failMedia();
                    if (count1 == 3) {
                        score += speedText;
                        successMedia();
                    }
                }
        }

    }

    private void successMedia() {
        soundThread = new SoundThread(context,0);  // Thraed를 상속받은 SoundThread클래스 생성
        list2.add(soundThread);           // list2에 soundThread클래스를 add함
        list2.get(soundCount).start();    // list2의 soundCount를 start함
        soundCount++;                      // soundCount를 ++시킴으로써 이미 종료된 쓰레드는 list2에서 get할수가 없음
    }

    private void failMedia(){
        soundThread = new SoundThread(context,1);   // 위와 같음
        list2.add(soundThread);
        list2.get(soundCount).start();
        soundCount++;
    }

    public void onDraw(Canvas canvas) {
        paint.setTextSize(35);
        canvas.drawText("만 터치!", 640, 65, paint);
        canvas.drawBitmap(bitmap[count1], new Rect(0, 0, bitmap[2].getWidth(), bitmap[2].getHeight()), new Rect(530, 10, 630, 110), null); //터치를 해야하는 그림을 보여줌
        paint.setStrokeWidth(3.0f);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(530, 10, 630, 110, paint); // 터치를해야하는 그림을 감쌀 사각형 테두리
        paint1.setTextSize(45);
        paint1.setStrokeWidth(3.0f);
        paint1.setStyle(Paint.Style.STROKE);
        canvas.drawText(str, 5, 50, paint1);

        count++;
        if (count == 50)
            paint.setColor(Color.BLACK);   // 검정과 파란색으로 깜박거릴 애니메이션 효과
        if (count == 100) {
            paint.setColor(Color.BLUE);
            count = 0;
        }
        time++;
        if (time > 1000) {     // time이 1000이 넘으면
            count1 = rand.nextInt(4);   // 터치해야하는 그림이 랜덤으로 바뀜
            time = rand.nextInt(200) + 200;   // 터치해야하는 그림이 일정한주기로 바뀌지 않게 하기위해 time값을 랜덤하게 설정
        }

        touchTime++;

        for (int i = 0; i < list.size(); i++)
            canvas.drawBitmap(boomSprite, rects[list1.get(i).index], list.get(i), null);  // 그림 터치시에 터치는 효과를 보여줄 애니메이션을 그림

        if (touchTime > 60) {    // 그림을 일정시간 터치하지 않을시에
            list.clear();         // list를 클리어시킴 그래야 add된 값들이 계속 쌓이지 않게됨
            list1.clear();        // 위와같음
            list2.clear();        // 위와같음
            count4 = 0;          // count4도 0으로
            soundCount = 0;     // soundCount도 0으로
        }


    }

    private void startTimer(){  // 남은시간을 보여줄 타이머
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
               delta++;
               if(delta > 1000 && !mode) {   // delta가 1000보다 크고 게임이 정지상태가 아니면
                   second--;
                   delta = 0;
               }
               if(second == 0)     // 남은시간이 0이되면
                   mode = true;    // mode를 true로 해줌으로써 second가 -- 가 안되게 해줌
               str = "남은시간 : " + second;
            }
        }, 0, 1);
    }

}