package com.example.boyng.dodgegame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;

import java.util.Random;

public class TopToFall {
    private float xcount = 0;
    private float xxcount = 100;
    private float[] xCount = new float[6];
    private float[] xxCount = new float[6];
    public float[] x = new float[6];
    private float[] y = new float[6];
    private float[] xx = new float[6];
    private float[] yy = new float[6];
    public Rect[] rect = new Rect[5];
    private float[] xr = new float[6];
    private float xxr;
    private Rect bRect;
    private Bitmap hamburger;
    Random rand = new Random();

    public TopToFall(Bitmap hamburger) {
        for (int i = 0; i < 5; i++) {      //햄버거 그림들의 초기 좌표설정
            xCount[i] += xcount;
            xcount += 200;
            x[i] += xCount[i];
            xxCount[i] += xxcount;
            xxcount += 200;
            xx[i] += xxCount[i];
            y[i] = 0;
            yy[i] = 100;
        }
        this.hamburger = hamburger;
        bRect = new Rect(0, 0, hamburger.getWidth(), hamburger.getHeight()); //햄버거그림 크기로 rect생성
        randPo();  // 초기 그림의 x좌표로 얼마나 갈것인가에대한 값 설정함수
    }

    public void increase() {
        resetPos();  // 그림이 화면 밖으로 나가게되면 다시 좌표설정하는 함수
        for (int i = 0; i < 5; i++) {
            x[i] += xr[i];    //xr은 그림이 내려가면서 왼쪽으로 갈지 오른쪽으로 갈지 랜덤한 변수
            xx[i] += xr[i];
            y[i]++;
            yy[i]++;
            rect[i] = new Rect((int) x[i], (int) y[i], (int) xx[i], (int) yy[i]); // 햄버거 그림들의 좌표값을 rect형으로 만듬
        }
    }

    public void resetPos() { //이함수는 increase함수안에 있음
        for (int i = 0; i < 5; i++) {
            if (x[i] < -200 || x[i] > 1070 || y[i] > 2040) {  // 화면 밖으로 나가게되면
                y[i] = -rand.nextInt(200) - 100;   //y값을 랜덤하게 설정
                yy[i] = y[i] + 100;
                x[i] = xCount[i];
                xx[i] = xxCount[i];
                xxr = rand.nextFloat();
                xr[i] = rand.nextFloat() - xxr; //화면 밖으로 나갈때 마다 xr을 랜덤하게 설정, xxr을 빼주는 이유는 햄버거그림이 오른쪽으로만 가는걸 방지하기위함
            }
        }
    }

    public void randomSet(int index) {  //그림을 터치했을시 호출하는 함수, 터치한 그림을 화면밖으로 보내버림
        y[index] = -rand.nextInt(200) - 100;
        yy[index] = y[index] + 100;
        x[index] = xCount[index];
        xx[index] = xxCount[index];
        xxr = rand.nextFloat();
        xr[index] = rand.nextFloat() - xxr;
    }

    public void randPo() {    //생성자에 정의되 있음
        for (int i = 0; i < 5; i++) {
            xxr = rand.nextFloat();
            xr[i] = rand.nextFloat() - xxr;
        }
    }

    public void onDraw(Canvas canvas) {
        for (int i = 0; i < 5; i++)
            canvas.drawBitmap(hamburger, bRect, rect[i], null);
    }

}
