package com.example.boyng.dodgegame;

import android.util.Log;

public class MyThread extends Thread{
public int index;

    @Override
    public void run() {
        for(int i = 0; i < 9; i++){
            index = i;
            try {
                Thread.sleep(50);  // 50마다 한번씩 쉬어줌, 즉 터지는 효과 애니메이션 그림들을 50마다 바꿔줌
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
