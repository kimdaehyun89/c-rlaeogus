package com.example.boyng.dodgegame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;

public class UiEvent{
private Bitmap up, down;
private Rect rect, rect1, rect2, rect3;
private Paint paint;
private String str, str1, str2;
public int speed = 5;
public int speedText = 1;
public boolean mode;

    public UiEvent(Bitmap up, Bitmap down) {
        this.up = up;
        this.down = down;
        rect = new Rect(0, 0, up.getWidth(), up.getHeight());
        rect1 = new Rect(970, 60, 970 + up.getWidth(), 60 + up.getHeight());
        rect2 = new Rect(970, 150, 970 + up.getWidth(), 150 + up.getHeight());
        rect3 = new Rect(770, 20, 910, 110);
        paint = new Paint();
        str = "SPEED : " + speedText;
        str1 = "점수 : " + 0;
        str2 = "정지";
    }

    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(up, rect, rect1,null);     // 속도업 화살표 그림을 그림
        canvas.drawBitmap(down, rect, rect2, null);  // 속도다운 화살표 그림을 그림
        paint.setTextSize(35);
        canvas.drawText(str, 920, 40, paint);
        paint.setTextSize(55);
        paint.setStrokeWidth(3.0f);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawText(str1, 280, 60, paint);
        canvas.drawText(str2, 790, 80, paint);
    }

    public void click(Rect click, int score){  // 화면 터치시
        if(!mode) {    //정지 상태가 아닐때
            if (click.intersect(rect1) && speed > 1) // rect1영역 클릭시, rect1은 속도업 화살표 그림이 그려진 위치
                speed--;  // speed를 -- 시킴, speed는 MyView클래스의 Timer의 period에 들어감
            if (click.intersect(rect2) && speed < 5)  // 위와 같음
                speed++;  //위와 같음
            if (click.intersect(rect1) && speedText < 5) // 속도업 화살표 그림이 그려진 위치를 클릭시
                speedText++;
            if (click.intersect(rect2) && speedText > 1)  // 속도다운 화살표 그림이 그려진 위치를 클릭시
                speedText--;
        }
        if(click.intersect(rect3))    // 정지 텍스트가 그려준 위치를 클릭시
            mode =! mode;

        if(mode)
            str2 = "시작";
        else
            str2 = "정지";

        str = "SPEED : " + speedText;
        str1 = "점수 : " + score;

    }

}
