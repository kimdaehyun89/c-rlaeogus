package com.example.boyng.dodgegame;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;

import java.util.Random;

class BottomToUp {
    private float xcount = 0;
    private float xxcount = 100;
    private float[] xCount = new float[6];
    private float[] xxCount = new float[6];
    private float[] x = new float[6];
    private float[] y = new float[6];
    private float[] xx = new float[6];
    private float[] yy = new float[6];
    public Rect[] rect = new Rect[5];
    private float[] xr = new float[6];
    private float xxr;
    private Rect bRect;
    private Bitmap hotdog;
    Random rand = new Random();

    public BottomToUp(Bitmap hotdog){            // TopToFall클래스와 같음, 다른거는 y좌표가 -- 된다는것
        for (int i = 0; i < 5; i++) {
            xCount[i] += xcount;
            xcount += 200;
            x[i] += xCount[i];
            xxCount[i] += xxcount;
            xxcount += 200;
            xx[i] += xxCount[i];
            y[i] = 1770;
            yy[i] = 1870;
        }
        this.hotdog = hotdog;
        bRect = new Rect(0,0, hotdog.getWidth(), hotdog.getHeight());
        randPo();
    }

    public void increase() {
        resetPos();
        for (int i = 0; i < 5; i++) {
            x[i] += xr[i];
            xx[i] += xr[i];
            y[i]--;
            yy[i]--;
            rect[i] = new Rect((int)x[i], (int)y[i], (int)xx[i], (int)yy[i]);
        }
    }

    public void resetPos() {
        for (int i = 0; i < 5; i++) {
            if (x[i] < -200 || x[i] > 1070 || y[i] < -100) {
                y[i] = rand.nextInt(200)+2100;
                yy[i] = y[i] + 100;
                x[i] = xCount[i];
                xx[i] = xxCount[i];
                xxr = rand.nextFloat();
                xr[i] = rand.nextFloat() - xxr;
            }
        }
    }

    public void randomSet(int index) {
        y[index] = rand.nextInt(200)+2100;
        yy[index] = y[index] + 100;
        x[index] = xCount[index];
        xx[index] = xxCount[index];
        xxr = rand.nextFloat();
        xr[index] = rand.nextFloat() - xxr;
    }

    public void randPo() {
        for (int i = 0; i < 5; i++) {
            xxr = rand.nextFloat();
            xr[i] = rand.nextFloat() - xxr;
        }
    }

    public void onDraw(Canvas canvas) {
        for(int i = 0; i < 5; i++)
            canvas.drawBitmap(hotdog, bRect,rect[i],null);
    }

}
