# 오호라! 퍼즐
2009년 여름, 남해대학 교내 연구생 시절, 연구실 프로젝트로 만든 프로그램이다.  
C#.NET 3.5 - WinForm 에 GDI+ 를 이용했다.

## 특징
* 자동으로 퍼즐을 섞는 알고리즘을 개발 하여 적용
* 퍼즐 개수를 3x3 ~ 10x10 까지 자유롭게 분할 가능
* 퍼즐에 쓰일 이미지를 외부에서 가져다 쓸 수 있음
* 미리보기와 퍼즐 조각에 번호를 붙이는 기능 적용
* 사용할 이미지와 설명을 추가할 수 있는 별도 설정 파일 존재

## Licence
MIT

## Screen Shots
![](https://github.com/thesoncriel/dotnet.puzzle/blob/master/screenshots/001.png)
![](https://github.com/thesoncriel/dotnet.puzzle/blob/master/screenshots/002.png)
